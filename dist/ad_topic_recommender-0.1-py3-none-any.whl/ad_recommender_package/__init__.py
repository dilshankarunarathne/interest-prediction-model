# ad_topic_recommender/__init__.py
print("Using ad_topic_recommender package")
print("Created by Dilshan M. Karunarathne")
print("CEO, Altier Tech")

from .main import recommend_topic
