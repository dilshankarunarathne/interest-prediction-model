# ad-topic-suggestion-model
 An AI model for suggesting interested topics for social media advertising, based on the user's age and gender.
